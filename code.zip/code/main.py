import os
import torch
import numpy as np
import pandas as pd
import torch.nn as nn
from tqdm import tqdm
from model import MyModel
import torch.optim as optim
from parse_args import args
from metric import get_metric
from datetime import datetime
import torch.nn.functional as fn
from GradientBalance import GradientBalance
from torch_geometric.seed import seed_everything
from contrastive_learning import inter_contrastive
from data_preprocessing import process_data, dgl_heterograph

from contrastive_learning import similarity_contrastive

torch.autograd.set_detect_anomaly(True)

def get_shared_parameters(model, inter_contrastive_loss):
    nonshared_idx = -1

    inter_contrastive_loss.backward(retain_graph=True)

    for i, (name, param) in enumerate(model.named_parameters()):
        
        if param.grad is None or param.grad.equal(torch.zeros_like(param.grad)):
            nonshared_idx = i
            break

    model.zero_grad()

    return nonshared_idx

def train(model, drdr_graph, didi_graph,drdr_graph1, didi_graph1, drdipr_graph, drug_feature, disease_feature, protein_feature, X_train, X_test, Y_train, Y_test, drdr_matrix, didi_matrix,drdr_matrix1, didi_matrix1):
    cross_entropy = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), weight_decay=args.weight_decay, lr=args.lr)
    best_metric = -float("inf")
    best_metrics = None
    l_reports = []
    for epoch in tqdm(range(args.total_epochs)):
        model.train()
        train_score, (dr_fusion_final, di_fusion_final), (dr_sim_final, di_sim_final), (dr_sim_final1, di_sim_final1), (dr_ass_final, di_ass_final),_ = model(drdr_graph, didi_graph,drdr_graph1, didi_graph1, drdipr_graph, drug_feature, disease_feature, protein_feature, X_train)
        train_loss = cross_entropy(train_score, torch.flatten(Y_train))

        # 修改的地方
        drdr_merge = np.logical_and(drdr_matrix, drdr_matrix1).astype(int)
        didi_merge = np.logical_and(didi_matrix, didi_matrix1).astype(int)
        drdr_matrix = drdr_matrix.astype(int)
        didi_matrix = didi_matrix.astype(int)
        drdr_matrix1 = drdr_matrix1.astype(int)
        didi_matrix1 = didi_matrix1.astype(int)

        inter_contrastive_loss1 = inter_contrastive(drdr_merge, didi_merge, dr_ass_final, di_ass_final,dr_sim_final, di_sim_final)
        inter_contrastive_loss2 = inter_contrastive(drdr_merge, didi_merge, dr_ass_final, di_ass_final,dr_sim_final1, di_sim_final1)
        inter_contrastive_loss3 = inter_contrastive(drdr_merge, didi_merge, dr_sim_final, di_sim_final,dr_sim_final1, di_sim_final1)
        intra_contrastive_loss1 = similarity_contrastive(drdr_matrix, didi_matrix, dr_sim_final, di_sim_final)
        intra_contrastive_loss2 = similarity_contrastive(drdr_matrix1, didi_matrix1, dr_sim_final1, di_sim_final1)

        inter_contrastive_loss = inter_contrastive_loss1 + inter_contrastive_loss2 + inter_contrastive_loss3 + intra_contrastive_loss1 + intra_contrastive_loss2
        # inter_contrastive_loss = inter_contrastive_loss1 + inter_contrastive_loss2 + inter_contrastive_loss3
        # inter_contrastive_loss = intra_contrastive_loss1 + intra_contrastive_loss2

        all_loss = train_loss + args.contras_rate * inter_contrastive_loss
        # all_loss = train_loss

        optimizer.zero_grad()
        all_loss.backward()
        optimizer.step()

        # t-SNE节点特征
        # if (epoch == 0):
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_sim_0.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_sim_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_sim_0.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_sim_final.detach().numpy()).to_csv(text_file2)
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_sim1_0.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_sim_final1.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_sim1_0.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_sim_final1.detach().numpy()).to_csv(text_file2)
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_ass_0.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_ass_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_ass_0.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_ass_final.detach().numpy()).to_csv(text_file2)
        #
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_fusion_0.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_fusion_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_fusion_0.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_fusion_final.detach().numpy()).to_csv(text_file2)

        # if (epoch == args.total_epochs-1):
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_sim.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_sim_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_sim.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_sim_final.detach().numpy()).to_csv(text_file2)
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_sim1.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_sim_final1.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_sim1.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_sim_final1.detach().numpy()).to_csv(text_file2)
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_ass.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_ass_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_ass.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_ass_final.detach().numpy()).to_csv(text_file2)
        #
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/drug_fusion.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(dr_fusion_final.detach().numpy()).to_csv(text_file5)
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/disease_fusion.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(di_fusion_final.detach().numpy()).to_csv(text_file2)


        if use_cuda:
            torch.cuda.empty_cache()

        with torch.no_grad():
            model.eval()
            test_score, _, _, _, _, drdi_embedding = model(drdr_graph, didi_graph, drdr_graph1, didi_graph1,drdipr_graph, drug_feature, disease_feature, protein_feature, X_test)
        
        test_prob = fn.softmax(test_score, dim=-1)
        test_score = torch.argmax(test_score, dim=-1)

        # 将预测结果额外保存一份，此处为增添上的代码
        predict_result = test_prob
        predict_score = np.zeros((len(test_score), 1))

        test_prob = test_prob[:, 1]
        test_prob = test_prob.cpu().numpy()
        test_score = test_score.cpu().numpy()

        # t-SNE 节点对特征
        # if (epoch == 0):
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/after_training_0.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(drdi_embedding.detach().numpy()).to_csv(text_file5)
        # if (epoch == args.total_epochs-1):
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/after_training.csv".format(args.dataset,fold_i)
        #     pd.DataFrame(drdi_embedding.detach().numpy()).to_csv(text_file5)

        # 为保存结果添加的代码
        # if(epoch==args.total_epochs-1):
        #     text_file2 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/data_test_predict_result.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(test_score).to_csv(text_file2)
        #     for j in range(len(test_score)):
        #         predict_score[j]=predict_result[j][1]
        #     text_file3 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/data_test_predict_score.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(predict_score).to_csv(text_file3)

        #     text_file4 = "D:/pyproject/Biowork4/paper_GCGB-main/Datasets/{}/case.csv".format(args.dataset)
        #     unsamples=np.array(pd.read_csv(text_file4,header=None))
        #     unsamples_score, _, _, _, _, _ = model(drdr_graph, didi_graph, drdr_graph1, didi_graph1, drdipr_graph, drug_feature,
        #                                disease_feature, protein_feature, unsamples)
        #     unsamples_prob = fn.softmax(unsamples_score, dim=-1)
        #     unsamples_score = torch.argmax(unsamples_score, dim=-1)
        #     unsamples_prob1=(unsamples_prob.detach().numpy())
        #     unsamples_score1=(unsamples_score.detach().numpy())
        #     text_file5 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/data_unsamples_predict_result.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(unsamples_score1).to_csv(text_file5)
        #     un_predict_score=np.zeros((len(unsamples_prob1),1))
        #     for k in range(len(unsamples_prob1)):
        #         un_predict_score[k] = unsamples_prob1[k][1]
        #     text_file6 = "D:/pyproject/Biowork4/paper_GCGB-main/Outputs/{}/result/{}/data_unsample_predict_score.csv".format(args.dataset, fold_i)
        #     pd.DataFrame(un_predict_score).to_csv(text_file6)


        AUC, AUPR, accuracy, precision, recall, f1, mcc = get_metric(Y_test, test_score, test_prob)

        current_result = [epoch + 1, round(AUC, 5), round(AUPR, 5), round(accuracy, 5), round(precision, 5), round(recall, 5), round(f1, 5), round(mcc, 5)]
        l_reports.append("\t".join(map(str, current_result)) + "\n")
        
        if epoch % 10 ==0:
            print("\t".join(map(str, current_result)))

        best_metrics = current_result

        # mix_factor = AUC + AUPR
        # if mix_factor > best_metric:
        #     best_metric = mix_factor
        #     best_metrics = current_result

    return best_metrics


if __name__ == "__main__":
    torch.backends.cudnn.deterministic = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_cuda = torch.cuda.is_available()
    # torch.cuda.set_device(args.gpu)

    seed_everything(args.seed)

    d_data, d_data1, drdr_graph, didi_graph,  drdr_graph1, didi_graph1= process_data()
    drdr_graph = drdr_graph.to(device)
    didi_graph = didi_graph.to(device)
    # 新增部分
    drdr_graph1 = drdr_graph1.to(device)
    didi_graph1 = didi_graph1.to(device)
    l_results = []

    for fold_i in range(args.K_fold):
        print("fold: ", fold_i)

        # 固定数据集，此为训练集部分
        text_file = "D:/pyproject/Biowork4/TEMCL/data/{}/fold/{}/data_train.csv".format(args.dataset, fold_i)
        train_samples = np.array(pd.read_csv(text_file).iloc[:, 1:])

        # 数据不平衡数据集1：1.2
        # text_file = "D:/pyproject/Biowork4/TEMCL/data/{}/fold_imbalance/fold_{}/train_fold_{}.csv".format(args.dataset, fold_i,fold_i)
        # train_samples = np.array(pd.read_csv(text_file))

        np_X_train_fold_i = train_samples[:, 0:2]
        np_X_train_fold_i_positive = [row[:-1] for row in train_samples if row[-1] == 1]
        np_X_train_fold_i_negative = [row[:-1] for row in train_samples if row[-1] == 0]
        np_Y_train_fold_i = train_samples[:, -1]
    
        X_train = torch.LongTensor(np_X_train_fold_i).to(device)
        Y_train = torch.LongTensor(np_Y_train_fold_i).to(device)
        X_test = torch.LongTensor(d_data['X_test'][fold_i]).to(device)
        Y_test = d_data['Y_test'][fold_i].flatten()
    
        heterograph = dgl_heterograph(d_data, np_X_train_fold_i_positive)
        heterograph = heterograph.to(device)
        meta_g = heterograph.metagraph()

        model = MyModel(meta_g, d_data['drug_number'], d_data['disease_number'])
        model = model.to(device)

        drug_feature = torch.FloatTensor(d_data['drugfeature']).to(device)
        disease_feature = torch.FloatTensor(d_data['diseasefeature']).to(device)
        protein_feature = torch.FloatTensor(d_data['proteinfeature']).to(device)

        # drug_feature = torch.FloatTensor(d_data['dr']).to(device)
        # disease_feature = torch.FloatTensor(d_data['di']).to(device)
        # protein_feature = torch.FloatTensor(d_data['pr']).to(device)

        drdr_matrix_bool = d_data["drdr_matrix"]
        didi_matrix_bool = d_data["didi_matrix"]
        drdr_matrix_bool1 = d_data1["drdr_matrix"]
        didi_matrix_bool1 = d_data1["didi_matrix"]

        best_metrics = train(model, drdr_graph, didi_graph, drdr_graph1, didi_graph1,heterograph, drug_feature, disease_feature, protein_feature, X_train, X_test, Y_train, Y_test, drdr_matrix_bool, didi_matrix_bool,drdr_matrix_bool1, didi_matrix_bool1)

        if best_metrics is not None:
            l_results.append(best_metrics[1:])
            print(best_metrics)

    np_results = np.array(l_results)
    mean_result = np.round(np.mean(np_results, axis = 0), 4)
    var_result = np.round(np.var(np_results, axis = 0), 4)
    std_result = np.round(np.std(np_results, axis = 0), 4)

    print(mean_result)
    print(var_result)
    print(std_result)
