# import pandas as pd
# import numpy as np
# import os
# from sklearn.model_selection import StratifiedKFold
# from sklearn.utils import shuffle
#
# # ===================== 配置参数 =====================
# # 请修改为你的药物疾病关联矩阵文件路径（CSV格式）
# MATRIX_FILE_PATH = "D:/pyproject/Biowork4/TEMCL/data/C-dataset/adj.csv"
# # 正负样本比例（正:负 = 1:1.2）
# NEG_POS_RATIO = 2
# # 交叉验证折数
# N_FOLDS = 10
# # 数据保存根目录
# BASE_SAVE_DIR = "D:/pyproject/Biowork4/TEMCL/data/C-dataset/fold_imbalance"
# # 随机种子（保证结果可复现）
# RANDOM_SEED = 42
#
#
# # ===================== 核心代码 =====================
# def prepare_drug_disease_data():
#     # 1. 读取关联矩阵（假设第一列是药物ID，第一行是疾病ID）
#     print("正在读取药物疾病关联矩阵...")
#     try:
#         # 如果矩阵的行索引/列索引不是药物/疾病ID，改用下面这行（根据你的文件格式调整）
#         # adj_matrix = pd.read_csv(MATRIX_FILE_PATH, header=None)
#         adj_matrix = pd.read_csv(MATRIX_FILE_PATH, index_col=0)
#     except Exception as e:
#         print(f"读取文件失败：{e}")
#         return
#
#     # 2. 提取所有药物-疾病对及其标签
#     print("正在提取药物-疾病对...")
#     drug_disease_pairs = []
#     # 遍历矩阵的每一行（药物）和每一列（疾病）
#     for drug_idx in range(adj_matrix.shape[0]):
#         for disease_idx in range(adj_matrix.shape[1]):
#             # 获取药物ID、疾病ID、标签（1=有关联，0=无关联）
#             drug_id = adj_matrix.index[drug_idx] if adj_matrix.index.name else drug_idx
#             disease_id = adj_matrix.columns[disease_idx] if adj_matrix.columns.name else disease_idx
#             label = adj_matrix.iloc[drug_idx, disease_idx]
#             drug_disease_pairs.append([int(drug_id), int(disease_id), int(label)])
#
#     # 转换为DataFrame
#     all_pairs_df = pd.DataFrame(drug_disease_pairs, columns=['drug', 'disease', 'label'])
#     print(f"原始数据统计：")
#     print(f"  总样本数: {len(all_pairs_df)}")
#     print(f"  正样本数: {all_pairs_df[all_pairs_df['label'] == 1].shape[0]}")
#     print(f"  负样本数: {all_pairs_df[all_pairs_df['label'] == 0].shape[0]}")
#
#     # 3. 按1:1.2比例筛选负样本
#     print("\n正在按1:1.2比例筛选负样本...")
#     positive_samples = all_pairs_df[all_pairs_df['label'] == 1].copy()
#     negative_samples_all = all_pairs_df[all_pairs_df['label'] == 0].copy()
#
#     # 计算需要选取的负样本数量
#     negative_sample_count = int(len(positive_samples) * NEG_POS_RATIO)
#     # 随机选取负样本（设置随机种子保证可复现）
#     negative_samples_selected = negative_samples_all.sample(
#         n=negative_sample_count,
#         random_state=RANDOM_SEED
#     )
#
#     # 合并正负样本并打乱顺序
#     final_samples = pd.concat([positive_samples, negative_samples_selected], ignore_index=True)
#     final_samples = shuffle(final_samples, random_state=RANDOM_SEED).reset_index(drop=True)
#
#     print(f"筛选后数据统计：")
#     print(f"  总样本数: {len(final_samples)}")
#     print(f"  正样本数: {final_samples[final_samples['label'] == 1].shape[0]}")
#     print(f"  负样本数: {final_samples[final_samples['label'] == 0].shape[0]}")
#     print(f"  正负样本比例: 1:{len(negative_samples_selected) / len(positive_samples):.2f}")
#
#     # 4. 十折交叉验证划分
#     print("\n正在进行十折交叉验证划分...")
#     skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_SEED)
#
#     # 创建根目录
#     os.makedirs(BASE_SAVE_DIR, exist_ok=True)
#
#     # 执行划分并保存
#     for fold_idx, (train_idx, test_idx) in enumerate(skf.split(final_samples, final_samples['label'])):
#         # 创建当前折的文件夹
#         fold_dir = os.path.join(BASE_SAVE_DIR, f'fold_{fold_idx}')
#         os.makedirs(fold_dir, exist_ok=True)
#
#         # 划分训练集和测试集
#         train_df = final_samples.iloc[train_idx].copy().reset_index(drop=True)
#         test_df = final_samples.iloc[test_idx].copy().reset_index(drop=True)
#
#         # 保存为CSV文件（无索引，列名：drug, disease, label）
#         train_df.to_csv(os.path.join(fold_dir, f'train_fold_{fold_idx}.csv'), index=False)
#         test_df.to_csv(os.path.join(fold_dir, f'test_fold_{fold_idx}.csv'), index=False)
#
#         # 验证当前折的正负样本比例
#         train_pos = train_df[train_df['label'] == 1].shape[0]
#         train_neg = train_df[train_df['label'] == 0].shape[0]
#         test_pos = test_df[test_df['label'] == 1].shape[0]
#         test_neg = test_df[test_df['label'] == 0].shape[0]
#
#         print(f"  Fold {fold_idx} 完成：")
#         print(f"    训练集：{len(train_df)}样本（正{train_pos}/负{train_neg}，比例1:{train_neg / train_pos:.2f}）")
#         print(f"    测试集：{len(test_df)}样本（正{test_pos}/负{test_neg}，比例1:{test_neg / test_pos:.2f}）")
#         print(f"    保存路径：{fold_dir}")
#
#     print(f"\n✅ 所有数据处理完成！")
#     print(f"📁 数据根目录：{os.path.abspath(BASE_SAVE_DIR)}")
#
#
# # 执行主函数
# if __name__ == "__main__":
#     prepare_drug_disease_data()


import pandas as pd
import numpy as np
import os
from sklearn.model_selection import StratifiedKFold
from sklearn.utils import shuffle

# ===================== 配置参数 =====================
# 请修改为你的药物疾病关联矩阵文件路径（CSV格式）
MATRIX_FILE_PATH = "D:/pyproject/Biowork4/TEMCL/data/F-dataset/adj.csv"
# 正负样本比例（正:负 = 1:1.2）
NEG_POS_RATIO = 2
# 交叉验证折数
N_FOLDS = 10
# 数据保存根目录
BASE_SAVE_DIR = "D:/pyproject/Biowork4/TEMCL/data/F-dataset/fold_imbalance"
# 随机种子（保证结果可复现）
RANDOM_SEED = 42


# ===================== 核心代码 =====================
def prepare_drug_disease_data():
    # 1. 读取关联矩阵（假设第一列是药物ID，第一行是疾病ID）
    print("正在读取药物疾病关联矩阵...")
    try:
        # 如果矩阵的行索引/列索引不是药物/疾病ID，改用下面这行（根据你的文件格式调整）
        # adj_matrix = pd.read_csv(MATRIX_FILE_PATH, header=None)
        adj_matrix = pd.read_csv(MATRIX_FILE_PATH, index_col=0)
    except Exception as e:
        print(f"读取文件失败：{e}")
        return

    # 2. 提取所有药物-疾病对及其标签
    print("正在提取药物-疾病对...")
    drug_disease_pairs = []
    # 遍历矩阵的每一行（药物）和每一列（疾病）
    for drug_idx in range(adj_matrix.shape[0]):
        for disease_idx in range(adj_matrix.shape[1]):
            # 获取药物ID、疾病ID、标签（1=有关联，0=无关联）
            drug_id = adj_matrix.index[drug_idx] if adj_matrix.index.name else drug_idx
            disease_id = adj_matrix.columns[disease_idx] if adj_matrix.columns.name else disease_idx
            label = adj_matrix.iloc[drug_idx, disease_idx]
            drug_disease_pairs.append([int(drug_id), int(disease_id), int(label)])

    # 转换为DataFrame
    all_pairs_df = pd.DataFrame(drug_disease_pairs, columns=['drug', 'disease', 'label'])
    print(f"原始数据统计：")
    print(f"  总样本数: {len(all_pairs_df)}")
    print(f"  正样本数: {all_pairs_df[all_pairs_df['label'] == 1].shape[0]}")
    print(f"  负样本数: {all_pairs_df[all_pairs_df['label'] == 0].shape[0]}")

    # 3. 按1:1.2比例筛选负样本
    print("\n正在按1:1.2比例筛选负样本...")
    positive_samples = all_pairs_df[all_pairs_df['label'] == 1].copy()
    negative_samples_all = all_pairs_df[all_pairs_df['label'] == 0].copy()

    # 计算需要选取的负样本数量
    negative_sample_count = int(len(positive_samples) * NEG_POS_RATIO)
    # 随机选取负样本（设置随机种子保证可复现）
    negative_samples_selected = negative_samples_all.sample(
        n=negative_sample_count,
        random_state=RANDOM_SEED
    )

    # 合并正负样本并打乱顺序
    final_samples = pd.concat([positive_samples, negative_samples_selected], ignore_index=True)
    final_samples = shuffle(final_samples, random_state=RANDOM_SEED).reset_index(drop=True)

    print(f"筛选后数据统计：")
    print(f"  总样本数: {len(final_samples)}")
    print(f"  正样本数: {final_samples[final_samples['label'] == 1].shape[0]}")
    print(f"  负样本数: {final_samples[final_samples['label'] == 0].shape[0]}")
    print(f"  正负样本比例: 1:{len(negative_samples_selected) / len(positive_samples):.2f}")

    # 4. 十折交叉验证划分
    print("\n正在进行十折交叉验证划分...")
    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_SEED)

    # 创建根目录
    os.makedirs(BASE_SAVE_DIR, exist_ok=True)

    # 执行划分并保存
    for fold_idx, (train_idx, test_idx) in enumerate(skf.split(final_samples, final_samples['label'])):
        # 创建当前折的文件夹
        fold_dir = os.path.join(BASE_SAVE_DIR, f'fold_{fold_idx}')
        os.makedirs(fold_dir, exist_ok=True)

        # 划分训练集和测试集
        train_df = final_samples.iloc[train_idx].copy().reset_index(drop=True)
        test_df = final_samples.iloc[test_idx].copy().reset_index(drop=True)

        # 保存为CSV文件（无索引，列名：drug, disease, label）
        train_df.to_csv(os.path.join(fold_dir, f'train_fold_{fold_idx}.csv'), index=False)
        test_df.to_csv(os.path.join(fold_dir, f'test_fold_{fold_idx}.csv'), index=False)

        # 验证当前折的正负样本比例
        train_pos = train_df[train_df['label'] == 1].shape[0]
        train_neg = train_df[train_df['label'] == 0].shape[0]
        test_pos = test_df[test_df['label'] == 1].shape[0]
        test_neg = test_df[test_df['label'] == 0].shape[0]

        print(f"  Fold {fold_idx} 完成：")
        print(f"    训练集：{len(train_df)}样本（正{train_pos}/负{train_neg}，比例1:{train_neg / train_pos:.2f}）")
        print(f"    测试集：{len(test_df)}样本（正{test_pos}/负{test_neg}，比例1:{test_neg / test_pos:.2f}）")
        print(f"    保存路径：{fold_dir}")

    print(f"\n✅ 所有数据处理完成！")
    print(f"📁 数据根目录：{os.path.abspath(BASE_SAVE_DIR)}")


# 执行主函数
if __name__ == "__main__":
    prepare_drug_disease_data()