import math
import torch
import torch.nn as nn
import dgl.nn.pytorch
from parse_args import args
import torch.nn.functional as F
from graph_transformer import GraphTransformer

device = torch.device('cuda')

def multiple_operator(a, b):
    return a * b

def rotate_operator(a, b):
    a_re, a_im = a.chunk(2, dim=-1)
    b_re, b_im = b.chunk(2, dim=-1)
    message_re = a_re * b_re - a_im * b_im
    message_im = a_re * b_im + a_im * b_re
    message = torch.cat([message_re, message_im], dim=-1)
    return message

class AttentionInteraction(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.attn = nn.Linear(feat_dim * 2, 1)

    def forward(self, a, b):
        cross_feat = torch.cat([a, b], dim=-1)
        alpha = torch.sigmoid(self.attn(cross_feat))
        return alpha * a + (1 - alpha) * b

class GatedInteraction(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(feat_dim * 2, feat_dim),
            nn.Sigmoid()
        )

    def forward(self, a, b):
        gate = self.gate(torch.cat([a, b], dim=-1))
        return gate * a + (1 - gate) * b


class DynamicFusion(nn.Module):
    def __init__(self, feat_dim, num_features=6):
        super().__init__()
        self.weights = nn.Linear(feat_dim * 2, num_features)
        self.feat_dim = feat_dim

    def forward(self, features_list):
        concat_input = torch.cat([features_list[0], features_list[1]], dim=-1)
        weights = torch.softmax(self.weights(concat_input), dim=-1)

        weighted_features = 0
        for i, feat in enumerate(features_list):
            if feat.size(-1) != self.feat_dim:
                feat = nn.Linear(feat.size(-1), self.feat_dim)(feat)
            weighted_features += weights[..., i].unsqueeze(-1) * feat

        return weighted_features

class EnhancedFusion(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.dynamic_fusion = DynamicFusion(feat_dim)

    def forward(self, features_list):
        dynamic_out = self.dynamic_fusion(features_list)
        return dynamic_out

class EnhancedInteraction(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.multiple = multiple_operator
        self.rotate = rotate_operator
        self.attention = AttentionInteraction(feat_dim)
        self.gated = GatedInteraction(feat_dim)
        self.fusion = EnhancedFusion(feat_dim)

    def forward(self, dr, di):
        m_res = self.multiple(dr, di)
        r_res = self.rotate(dr, di)

        attn_res = self.attention(dr, di)
        gate_res = self.gated(dr, di)

        features_list = [dr, di, m_res, r_res, attn_res, gate_res]
        fused = self.fusion(features_list)

        return fused


class EnhancedInteraction1(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.multiple = multiple_operator
        self.rotate = rotate_operator
        self.attention = AttentionInteraction(feat_dim)
        self.gated = GatedInteraction(feat_dim)


    def forward(self, dr, di):
        all_features = torch.cat([dr, di], dim=-1)
        return all_features

class Multi_Head_Self_ATT(nn.Module):

    def __init__(self, head_num, in_channels, out_channels):
        super(Multi_Head_Self_ATT, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.head_num = head_num

        self.k_lin = nn.Linear(self.in_channels, self.out_channels)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.k_lin.weight)
        nn.init.constant_(self.k_lin.bias, 0.0)

    def forward(self, x1, x2):
        x = torch.stack([x1, x2], dim = 1)
        B, M, _ = x.shape
        H, D = self.head_num, self.out_channels // self.head_num

        q = torch.mean(x, dim = 1).view(B, 1, H, D)
        k = self.k_lin(x).view(x.shape[:-1] + (H, D))
        v = x.view(x.shape[:-1] + (H, D))

        q = q.permute(0,2,1,3)
        k = k.permute(0,2,3,1)
        v = v.permute(0,2,1,3)

        alpha = F.softmax((q @ k / math.sqrt(q.size(-1))), dim=-1)

        o = alpha @ v 

        output = o.permute(0,2,1,3).reshape((B, H * D))

        return output

class Attention(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(Attention, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels

        self.W1 = nn.Linear(self.in_channels, self.out_channels)
        self.W2 = nn.Linear(self.out_channels, 1)
        self.reset_parameters()


    def forward(self, tensor_a, tensor_b):
        feature = torch.stack([tensor_a, tensor_b], dim = 1)

        tensor = torch.tanh(self.W1(feature))
        tensor = self.W2(tensor).squeeze(2) 
        attention = F.softmax(tensor, dim=1).unsqueeze(1)

        output = torch.matmul(attention, feature).squeeze(1)

        return output

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.W1.weight)
        nn.init.xavier_uniform_(self.W2.weight)
        nn.init.constant_(self.W1.bias, 0.0)
        nn.init.constant_(self.W2.bias, 0.0)


class MLPPredictor(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, 1024),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(1024, 1024),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 2)
        )
    def forward(self, x):
        return self.mlp(x)



class TransformerPredictor(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=in_dim, nhead=8),
            num_layers=2
        )
        self.head = nn.Linear(in_dim, 2)

    def forward(self, x):
        x = x.unsqueeze(0)
        x = self.encoder(x).squeeze(0)
        return self.head(x)


class BilinearPredictor(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.drug_proj = nn.Linear(in_dim//2, 256)
        self.disease_proj = nn.Linear(in_dim//2, 256)
        self.bilinear = nn.Bilinear(256, 256, 1)
        self.fc = nn.Linear(1, 2)
        self.in_dim = in_dim

    def forward(self, x):
        drug = self.drug_proj(x[:, :self.in_dim//2])
        disease = self.disease_proj(x[:, self.in_dim//2:])
        score = self.bilinear(drug, disease)
        return self.fc(score)


class EnsembleFramework(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.mlp = MLPPredictor(in_dim)

    def forward(self, x, graph=None):
        s1 = self.mlp(x)
        return s1


class SimMatrixTransformer(nn.Module):
    def __init__(self, input_dim, d_model, nhead, num_layers):
        super().__init__()
        self.embedding = nn.Linear(input_dim, d_model)
        encoder_layer = nn.TransformerEncoderLayer(d_model, nhead)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)

    def forward(self, sim_matrix):
        # Fdataset, 添加自环，确保没有孤立节点
        # sim_matrix = sim_matrix + torch.eye(sim_matrix.size(0), device=sim_matrix.device)

        deg = torch.diag(torch.sum(sim_matrix, dim=1))
        deg_inv_sqrt = torch.inverse(torch.sqrt(deg))
        adj_norm = deg_inv_sqrt @ sim_matrix @ deg_inv_sqrt

        h = self.embedding(adj_norm)
        attn_mask = (adj_norm == 0).float() * -1e9
        output = self.transformer(h.unsqueeze(1), mask=attn_mask)

        return output.squeeze(1)

# 以相似性矩阵作为输入数据
class MultiHeadSimTransformer(nn.Module):
    def __init__(self, input_dim, d_model, nhead, num_layers, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.heads = nn.ModuleList([SimMatrixTransformer(input_dim, d_model, nhead, num_layers)
            for _ in range(num_heads)
        ])

    def forward(self, sim_matrix):
        return [head(sim_matrix) for head in self.heads]


class MyModel(nn.Module):
    def __init__(self, meta_g, drug_number, disease_number):
        super(MyModel, self).__init__()
        self.drug_number = drug_number
        self.meta_g = meta_g
        self.disease_number = disease_number

        # Cdataset
        self.drug_linear = nn.Linear(663, args.hgt_out_dim)
        self.protein_linear = nn.Linear(993, args.hgt_out_dim)
        self.disease_linear = nn.Linear(409, args.hgt_out_dim)

        # Bdataset
        # self.drug_linear = nn.Linear(269, args.hgt_out_dim)
        # self.disease_linear = nn.Linear(598, args.hgt_out_dim)
        # self.protein_linear = nn.Linear(1021, args.hgt_out_dim)

        # Fdataset
        # self.drug_linear = nn.Linear(592, args.hgt_out_dim)
        # self.disease_linear = nn.Linear(313, args.hgt_out_dim)
        # self.protein_linear = nn.Linear(2741, args.hgt_out_dim)


        self.gt_drug = GraphTransformer(device, args.gt_layer, self.drug_number, args.gt_out_dim, args.gt_out_dim, args.gt_head, args.dropout)
        self.gt_disease = GraphTransformer(device, args.gt_layer, self.disease_number, args.gt_out_dim, args.gt_out_dim, args.gt_head, args.dropout)
        self.gt_drug1 = GraphTransformer(device, args.gt_layer, self.drug_number, args.gt_out_dim, args.gt_out_dim,args.gt_head, args.dropout)
        self.gt_disease1 = GraphTransformer(device, args.gt_layer, self.disease_number, args.gt_out_dim, args.gt_out_dim,args.gt_head, args.dropout)

        self.hgt_dgl = dgl.nn.pytorch.conv.HGTConv(args.hgt_out_dim, int(args.hgt_out_dim/args.hgt_head), args.hgt_head, len(self.meta_g.nodes()), len(self.meta_g.edges()), args.dropout)

        self.hgt = nn.ModuleList()
        for _ in range(args.hgt_layer):
            self.hgt.append(self.hgt_dgl)

        self.drug_fusion_atts = nn.ModuleList()
        self.disease_fusion_atts = nn.ModuleList()

        for _ in range(args.hgt_layer):
            att = Multi_Head_Self_ATT(4, args.hgt_out_dim, args.hgt_out_dim)
            self.drug_fusion_atts.append(att)
        
        for _ in range(args.hgt_layer):
            att = Multi_Head_Self_ATT(4, args.hgt_out_dim, args.hgt_out_dim)
            self.disease_fusion_atts.append(att)

        self.interaction = EnhancedInteraction1(args.gt_out_dim)
        self.integrator = EnsembleFramework(args.gt_out_dim * 2)

        # Cdataset
        self.trans_sim_dr0 = MultiHeadSimTransformer(input_dim=663, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        self.trans_sim_di0 = MultiHeadSimTransformer(input_dim=409, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        self.trans_sim_dr = MultiHeadSimTransformer(input_dim=663, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        self.trans_sim_di = MultiHeadSimTransformer(input_dim=409, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)

        # Bdataset
        # self.trans_sim_dr0 = MultiHeadSimTransformer(input_dim=269, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_di0 = MultiHeadSimTransformer(input_dim=598, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_dr = MultiHeadSimTransformer(input_dim=269, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_di = MultiHeadSimTransformer(input_dim=598, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)

        # Fdataset
        # self.trans_sim_dr0 = MultiHeadSimTransformer(input_dim=592, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_di0 = MultiHeadSimTransformer(input_dim=313, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_dr = MultiHeadSimTransformer(input_dim=592, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)
        # self.trans_sim_di = MultiHeadSimTransformer(input_dim=313, d_model=args.gt_out_dim, nhead=8, num_layers=args.gt_layer,num_heads=args.gt_head)


    def forward(self, drdr_graph, didi_graph,drdr_graph1, didi_graph1, drdipr_graph, drug_feature, disease_feature, protein_feature, sample):
        # 根据不同的矩阵信息，采用不同类型的Transformer，基于图的Transformer和基于相似性的Transformer
        l_dr_sim = self.gt_drug(drdr_graph)
        l_di_sim = self.gt_disease(didi_graph)
        l_dr_sim1 = self.trans_sim_dr(drdr_graph1)
        l_di_sim1 = self.trans_sim_di(didi_graph1)

        # 根据不同的矩阵信息，采用不同类型的Transformer，互换Transformer的处理方式
        # l_dr_sim = self.trans_sim_dr(drdr_graph)
        # l_di_sim = self.trans_sim_di(didi_graph)
        # l_dr_sim1 = self.gt_drug(drdr_graph1)
        # l_di_sim1 = self.gt_disease(didi_graph1)

        # 只采用基于图的Transformer
        # l_dr_sim = self.gt_drug(drdr_graph)
        # l_di_sim = self.gt_disease(didi_graph)
        # l_dr_sim1 = self.gt_drug1(drdr_graph1)
        # l_di_sim1 = self.gt_disease1(didi_graph1)

        # 只采用基于相似性的Transformer
        # l_dr_sim = self.trans_sim_dr0(drdr_graph)
        # l_di_sim = self.trans_sim_di0(didi_graph)
        # l_dr_sim1 = self.trans_sim_dr(drdr_graph1)
        # l_di_sim1 = self.trans_sim_di(didi_graph1)


        drug_feature = self.drug_linear(drug_feature)
        protein_feature = self.protein_linear(protein_feature)
        disease_feature = self.disease_linear(disease_feature)

        feature_dict = {
            'drug': drug_feature,
            'disease': disease_feature,
            'protein': protein_feature
        }

        drdipr_graph.ndata['h'] = feature_dict
        g = dgl.to_homogeneous(drdipr_graph, ndata='h')

        feature = torch.cat((drug_feature, disease_feature, protein_feature), dim=0)

        l_dr_ass = []
        l_di_ass = []
        l_dr_fusion = []
        l_di_fusion = []

        for layer in self.hgt:
            hgt_out = layer(g, feature, g.ndata['_TYPE'], g.edata['_TYPE'], presorted=True)
            feature = hgt_out
            l_dr_ass.append(hgt_out[:self.drug_number, :])
            l_di_ass.append(hgt_out[self.drug_number:self.disease_number + self.drug_number, :])


        for i, (dr_sim, dr_sim1, dr_ass) in enumerate(zip(l_dr_sim, l_dr_sim1, l_dr_ass)):
            temp_fusion = self.drug_fusion_atts[i](dr_sim, dr_sim1)
            dr_fusion_i = self.drug_fusion_atts[i](temp_fusion, dr_ass)
            l_dr_fusion.append(dr_fusion_i)

        for i, (di_sim, di_sim1, di_ass) in enumerate(zip(l_di_sim, l_di_sim1, l_di_ass)):
            temp_fusion = self.disease_fusion_atts[i](di_sim, di_sim1)
            di_fusion_i = self.disease_fusion_atts[i](temp_fusion, di_ass)
            l_di_fusion.append(di_fusion_i)

        dr_fusion_final = torch.mean(torch.stack(l_dr_fusion, dim = 1), dim = 1)
        di_fusion_final = torch.mean(torch.stack(l_di_fusion, dim = 1), dim = 1)

        dr_sim_final = torch.mean(torch.stack(l_dr_sim, dim = 1), dim = 1)
        di_sim_final = torch.mean(torch.stack(l_di_sim, dim = 1), dim = 1)

        dr_sim_final1 = torch.mean(torch.stack(l_dr_sim1, dim=1), dim=1)
        di_sim_final1 = torch.mean(torch.stack(l_di_sim1, dim=1), dim=1)

        dr_ass_final = torch.mean(torch.stack(l_dr_ass, dim = 1), dim = 1)
        di_ass_final = torch.mean(torch.stack(l_di_ass, dim = 1), dim = 1)

        dr_sample = dr_fusion_final[sample[:, 0]]
        di_sample = di_fusion_final[sample[:, 1]]
        drdi_embedding = self.interaction(dr_sample,di_sample)

        output = self.integrator(drdi_embedding)

        return output, (dr_fusion_final, di_fusion_final), (dr_sim_final, di_sim_final), (dr_sim_final1, di_sim_final1), (dr_ass_final, di_ass_final), drdi_embedding
    
    def load(self, checkpoint_dir):
        self.load_state_dict(torch.load(checkpoint_dir))